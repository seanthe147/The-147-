# Android Upload Keystore Credentials

These credentials are used in conjunction with your Android upload keystore file to sign your app for distribution.

## Credential Values

- Android upload keystore password: 10f5a032623c240ee66cb7267bd4af23
- Android key alias: 6fee616d28fef2a4cb3cd8aa3d94f041
- Android key password: 18ea75e4791276c18b746903b5450e4b
      